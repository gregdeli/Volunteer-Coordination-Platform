<?php

// Define your constants
define("MAX_LENGTH", 30);